import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/enums/font_size_option.dart';
import 'package:moo_logue/app/core/theme/app_theme.dart';

class ThemeController extends GetxController {
  var themeMode = ThemeMode.system.obs;
  var fontSizeOption = FontSizeOption.medium.obs;

  ThemeData get lightTheme => AppTheme.light();
  ThemeData get darkTheme => AppTheme.dark();

  void toggleTheme(bool isDark) {
    themeMode.value = isDark ? ThemeMode.dark : ThemeMode.light;
    Get.changeThemeMode(themeMode.value);
  }

  void setFontSize(FontSizeOption option) {
    fontSizeOption.value = option;
    Get.changeThemeMode(themeMode.value);
  }
}
