import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/modules/home/controllers/leader_board_controller.dart';
import 'package:moo_logue/app/widgets/common_home_app_bar.dart';

class LearnBoardView extends StatelessWidget {
  final controller = Get.put(LeaderBoardController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomHomeAppBar(),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.horizontalPadding),
        child: Center(
          child: Column(
            children: [
              20.h.heightBox,
              Text(
                AppString.topMooListeners,
                style: context.textTheme.displayMedium?.copyWith(),
              ),
              16.h.heightBox,
              Text(
                AppString.topMooListenersDisc,
                style: context.textTheme.bodyMedium?.copyWith(
                  fontWeight: FontWeight.w400,
                ),
              ),
              20.h.heightBox,
              Obx(
                () => Expanded(
                  child: Column(
                    children: [
                      Container(
                        width: 400.w,
                        height: 36.h,
                        decoration: BoxDecoration(
                          color: AppColors.closeIconBgColor.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(5.r),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            buildTabButton(
                              title: AppString.today,
                              index: 0,
                              context: context,
                            ),
                            buildTabButton(
                              title: AppString.week,
                              index: 1,
                              context: context,
                            ),
                            buildTabButton(
                              title: AppString.month,
                              index: 2,
                              context: context,
                            ),
                            buildTabButton(
                              title: AppString.allTime,
                              index: 3,
                              context: context,
                            ),
                          ],
                        ),
                      ),
                      20.h.heightBox,
                      controller.selectedIndex.value == 1
                          ? Expanded(
                              child: ListView.builder(
                                itemCount: controller.weekList.length,
                                itemBuilder: (context, index) {
                                  return Column(
                                    children: [
                                      Container(
                                        // height: 78,
                                        color: index >= 3
                                            ? Colors.transparent
                                            : context.isDarkMode
                                            ? AppColors.closeIconBgColor
                                            : AppColors.closeIconBgColor
                                                  .withValues(alpha: 0.50),
                                        child: Column(
                                          children: [
                                            Padding(
                                              padding:
                                                  const EdgeInsets.symmetric(
                                                    vertical: 18,
                                                    horizontal: 8,
                                                  ),
                                              child: Row(
                                                children: [
                                                  if (index < 3)
                                                    SvgPicture.asset(
                                                      "${controller.weekList[index]['Icon']}",
                                                      height: 25.h,
                                                      width: 25.w,
                                                    )
                                                  else
                                                    CircleAvatar(
                                                      backgroundColor:
                                                          Colors.transparent,
                                                      radius: 12,
                                                      child: Text(
                                                        "${controller.weekList[index]['Digit']}",
                                                        style: context
                                                            .textTheme
                                                            .titleLarge
                                                            ?.copyWith(
                                                              fontSize: 14.sp,
                                                              color: AppColors
                                                                  .primary,
                                                            ),
                                                      ),
                                                    ),
                                                  10.w.widthBox,
                                                  Image.asset(
                                                    "${controller.weekList[index]['Image']}",
                                                    height: 30.h,
                                                    width: 30.w,
                                                  ),
                                                  10.w.widthBox,
                                                  Column(
                                                    crossAxisAlignment:
                                                        CrossAxisAlignment
                                                            .start,
                                                    children: [
                                                      Text(
                                                        "${controller.weekList[index]['Title']}",
                                                        style: context.textTheme.bodyMedium?.copyWith(
                                                          fontWeight:
                                                              FontWeight.w700,
                                                          color: index < 3
                                                              ? context.isDarkMode
                                                                    ? AppColors
                                                                          .primary
                                                                    : AppColors
                                                                          .primary
                                                              : context
                                                                    .isDarkMode
                                                              ? AppColors
                                                                    .whiteColor
                                                              : AppColors
                                                                    .primaryTextColor,
                                                        ),
                                                      ),
                                                      2.5.h.heightBox,
                                                      Text(
                                                        "${controller.weekList[index]['SubTitle']}",
                                                        style: context.textTheme.labelSmall?.copyWith(
                                                          fontSize: 10.sp,
                                                          color: index < 3
                                                              ? context.isDarkMode
                                                                    ? AppColors
                                                                          .primaryTextColor
                                                                    : AppColors
                                                                          .primaryTextColor
                                                              : context
                                                                    .isDarkMode
                                                              ? AppColors
                                                                    .closeIconBgColor
                                                                    .withValues(
                                                                      alpha:
                                                                          0.75,
                                                                    )
                                                              : AppColors
                                                                    .primaryTextColor,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  Spacer(),
                                                  if (index == 0 ||
                                                      index == 4 ||
                                                      index == 5)
                                                    Container(
                                                      height: 35.h,
                                                      width: 38.w,
                                                      decoration: BoxDecoration(
                                                        color:
                                                            AppColors.primary,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              100,
                                                            ),
                                                      ),
                                                      child: Center(
                                                        child: SvgPicture.asset(
                                                          AppAssets
                                                              .weekstarIcon,
                                                          height: 16.h,
                                                          width: 18.w,
                                                        ),
                                                      ),
                                                    )
                                                  else
                                                    Container(
                                                      height: 35.h,
                                                      width: 38.w,
                                                      decoration: BoxDecoration(
                                                        color:
                                                            Colors.transparent,
                                                        borderRadius:
                                                            BorderRadius.circular(
                                                              100,
                                                            ),
                                                      ),
                                                      child: SizedBox(),
                                                    ),
                                                  10.w.widthBox,
                                                  Container(
                                                    height: 31.h,
                                                    width: 66.w,
                                                    decoration: BoxDecoration(
                                                      color: Colors.transparent,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            100,
                                                          ),
                                                      border: Border.all(
                                                        color:
                                                            AppColors.primary,
                                                        width: 1,
                                                      ),
                                                    ),
                                                    child: Row(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment
                                                              .center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment
                                                              .center,
                                                      children: [
                                                        Text(
                                                          "${controller.weekList[index]['Points']}",
                                                          style: context
                                                              .textTheme
                                                              .titleLarge
                                                              ?.copyWith(
                                                                fontSize: 10.sp,
                                                                color: AppColors
                                                                    .primary,
                                                              ),
                                                        ),
                                                        2.w.widthBox,
                                                        Text(
                                                          AppString.points,
                                                          style: context
                                                              .textTheme
                                                              .titleLarge
                                                              ?.copyWith(
                                                                fontSize: 10.sp,
                                                                color: AppColors
                                                                    .primary,
                                                              ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Divider(
                                              height: 0,
                                              color: index < 3
                                                  ? context.isDarkMode
                                                        ? AppColors.dividerColor
                                                        : AppColors
                                                              .primaryTextColor
                                                              .withValues(
                                                                alpha: 0.1,
                                                              )
                                                  : context.isDarkMode
                                                  ? AppColors.closeIconBgColor
                                                        .withValues(alpha: 0.25)
                                                  : AppColors.primaryTextColor
                                                        .withValues(alpha: 0.1),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  );
                                },
                              ),
                            )
                          : Column(children: []),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget buildTabButton({
  required String title,
  required int index,
  BuildContext? context,
}) {
  final controller = Get.find<LeaderBoardController>();

  bool isSelected = controller.selectedIndex.value == index;

  return GestureDetector(
    onTap: () {
      controller.updateIndex(index);
    },
    child: Container(
      width: 95.w,
      height: 28.h,
      decoration: BoxDecoration(
        color: isSelected ? AppColors.primary : Colors.transparent,
        borderRadius: BorderRadius.circular(5.r),
      ),
      child: Center(
        child: Text(
          title,
          style: TextStyle(
            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
            color: isSelected
                ? AppColors.whiteColor
                : context!.isDarkMode
                ? AppColors.whiteColor
                : AppColors.primaryTextColor,
          ),
        ),
      ),
    ),
  );
}
