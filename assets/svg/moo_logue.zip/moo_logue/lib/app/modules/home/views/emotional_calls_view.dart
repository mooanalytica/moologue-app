import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/modules/home/controllers/emotional_calls_controller.dart';
import 'package:moo_logue/app/routes/app_routes.dart';
import 'package:moo_logue/app/routes/index.js.dart';
import 'package:moo_logue/app/widgets/common_home_app_bar.dart';
import 'package:moo_logue/app/widgets/custom_button.dart';
import 'package:moo_logue/app/widgets/rounded_asset_image.dart';

class EmotionalCallsView extends StatelessWidget {
  final controller = Get.put(EmotionalCallsController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomHomeAppBar(),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.horizontalPadding),
        child: Column(
          children: [
            25.heightBox,
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () {
                    ctx!.pop();
                  },
                  child: SvgPicture.asset(
                    AppAssets.arrowleftIcon,
                    colorFilter: ColorFilter.mode(
                      context.isDarkMode
                          ? AppColors.whiteColor
                          : AppColors.primaryTextColor,
                      BlendMode.srcIn,
                    ),
                  ),
                ),
                Text(
                  AppString.emotionalCalls,
                  style: context.textTheme.displayMedium?.copyWith(),
                ),
                SizedBox(),
              ],
            ),
            25.heightBox,
            Expanded(
              child: ListView.builder(
                physics: AlwaysScrollableScrollPhysics(),
                itemCount: controller.emotionalContainerList.length,
                shrinkWrap: true,
                scrollDirection: Axis.vertical,
                itemBuilder: (context, index) {
                  print(
                    'controller.emotionalContainerList.length======>${controller.emotionalContainerList.length}',
                  );
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(25),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                        child: Container(
                          width: 250.w,
                          decoration: BoxDecoration(
                            color: AppColors.closeIconBgColor.withValues(
                              alpha: 0.20,
                            ),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          padding: EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RoundedAssetImage(
                                imagePath:
                                    "${controller.emotionalContainerList[index]['emotionalContainerImage']}",
                                width: double.infinity,
                                height: 100.h,
                                fit: BoxFit.cover,
                                borderRadius: 20,
                              ),
                              20.heightBox,
                              Text(
                                "${controller.emotionalContainerList[index]['emotionalContainerName']}",
                                maxLines: 2,
                                style: context.textTheme.headlineMedium
                                    ?.copyWith(fontWeight: FontWeight.w600),
                              ),
                              20.heightBox,
                              Row(
                                children: [
                                  GestureDetector(
                                    onTap: () {
                                      ctx?.push(
                                        Routes.fenceInteractionCallView,
                                      );
                                    },
                                    child: Container(
                                      height: 40.h,
                                      width: 178.w,
                                      decoration: BoxDecoration(
                                        color: Colors.transparent,
                                        borderRadius: BorderRadius.circular(
                                          100,
                                        ),
                                        border: Border.all(
                                          color: AppColors.primary,
                                          width: 1,
                                        ),
                                      ),
                                      child: Center(
                                        child: Text(
                                          AppString.learnMore,
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.primary,
                                              ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  10.widthBox,
                                  Container(
                                    height: 40.h,
                                    width: 178.w,
                                    decoration: BoxDecoration(
                                      color: AppColors.primary,
                                      borderRadius: BorderRadius.circular(100),
                                      border: Border.all(
                                        color: AppColors.primary,
                                        width: 1,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Text(
                                          AppString.playSound,
                                          style: context.textTheme.bodySmall
                                              ?.copyWith(
                                                fontWeight: FontWeight.w600,
                                                color: AppColors.whiteColor,
                                              ),
                                        ),
                                        5.widthBox,
                                        SvgPicture.asset(
                                          AppAssets.playIcon,
                                          width: 13.w,
                                          height: 14.h,
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                              5.heightBox,
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
