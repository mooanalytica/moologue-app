import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';

class EmotionalCallsController extends GetxController {
  RxList<Map<String, dynamic>> emotionalContainerList = <Map<String, dynamic>>[
    {
      'emotionalContainerImage': AppAssets.emotionalOneImage,
      'emotionalContainerName': AppString.fenceInteractionCall,
    },
    {
      'emotionalContainerImage': AppAssets.emotionalTwoImage,
      'emotionalContainerName': AppString.impatienceCall,
    },
    {
      'emotionalContainerImage': AppAssets.emotionslThreeImage,
      'emotionalContainerName': AppString.feedingFrustration,
    },
    {
      'emotionalContainerImage': AppAssets.emotionalOneImage,
      'emotionalContainerName': AppString.painBellow,
    },
  ].obs;
}
