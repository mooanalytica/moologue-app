import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'dart:io';
import 'package:audio_waveforms/audio_waveforms.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart' as ja;
import 'package:http/http.dart' as http;
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';

class FenceInteractionCallController extends GetxController {
  final ja.AudioPlayer audioPlayer = ja.AudioPlayer();
  final PlayerController waveformController = PlayerController();
  Duration position = Duration.zero;
  Duration duration = Duration.zero;

  final String remoteUrl =
      "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3";

  bool isRepeating = false;
  bool isMuted = false;
  bool isPlaying = false;
  bool isReady = false;

  String? _audioFilePath;

  RxList<String> fenceCallList = [
    AppString.excitement,
    AppString.socialization,
    AppString.confidence,
  ].obs;

  @override
  void onInit() {
    super.onInit();
    setup();

    audioPlayer.positionStream.listen((pos) {
      position = pos;
      waveformController.seekTo(pos.inMilliseconds);
      update();
    });

    audioPlayer.durationStream.listen((dur) {
      if (dur != null) {
        duration = dur;
        update();
      }
    });

    audioPlayer.playerStateStream.listen((state) async {
      if (state.processingState == ja.ProcessingState.completed) {
        if (isRepeating) {
          await audioPlayer.seek(Duration.zero);
          await audioPlayer.play();
          await waveformController.seekTo(0);
          await waveformController.startPlayer();
        } else {
          await waveformController.seekTo(0);
          await waveformController.pausePlayer();
          isPlaying = false;
          update();
        }
      }
    });
  }

  Future<void> setup() async {
    try {
      final bytes = await http.get(Uri.parse(remoteUrl));
      final dir = await getApplicationDocumentsDirectory();
      final file = File('${dir.path}/temp_audio.mp3');
      await file.writeAsBytes(bytes.bodyBytes);

      _audioFilePath = file.path;

      await waveformController.preparePlayer(
        path: _audioFilePath!,
        shouldExtractWaveform: true,
        noOfSamples: 200,
      );
      await waveformController.seekTo(0);
      await audioPlayer.setFilePath(_audioFilePath!);

      isReady = true;
      update();
    } catch (e) {
      debugPrint('Error preparing player: $e');
    }
  }

  Future<void> togglePlayPause() async {
    final state = audioPlayer.playerState;
    final playing = state.playing;
    final completed = state.processingState == ja.ProcessingState.completed;

    if (completed) {
      await audioPlayer.seek(Duration.zero);
      await waveformController.stopPlayer();
      await waveformController.seekTo(0);
      await waveformController.preparePlayer(
        path: _audioFilePath!,
        shouldExtractWaveform: false,
      );

      WidgetsBinding.instance.addPostFrameCallback((_) async {
        await waveformController.startPlayer();
      });

      await audioPlayer.play();
    } else if (playing) {
      await audioPlayer.pause();
      await waveformController.pausePlayer();
    } else {
      await audioPlayer.play();
      await waveformController.startPlayer();
    }

    isPlaying = !playing || completed;
    update();
  }

  Future<void> skipForward() async {
    final position = await audioPlayer.position;
    final newPos = position + const Duration(seconds: 5);
    await audioPlayer.seek(newPos);
    await waveformController.seekTo(newPos.inMilliseconds);
  }

  Future<void> skipBackward() async {
    final position = await audioPlayer.position;
    final newPos = position - const Duration(seconds: 5);
    final validPos = newPos < Duration.zero ? Duration.zero : newPos;
    await audioPlayer.seek(validPos);
    await waveformController.seekTo(validPos.inMilliseconds);
  }

  Future<void> toggleMute() async {
    isMuted = !isMuted;
    await audioPlayer.setVolume(isMuted ? 0.0 : 1.0);
    update();
  }

  Future<void> toggleRepeat() async {
    if (_audioFilePath == null) return;

    await audioPlayer.seek(Duration.zero);
    await audioPlayer.play();

    await waveformController.stopPlayer();
    await waveformController.seekTo(0);
    await waveformController.preparePlayer(
      path: _audioFilePath!,
      shouldExtractWaveform: false,
    );

    WidgetsBinding.instance.addPostFrameCallback((_) async {
      await waveformController.startPlayer();
      isPlaying = true;
      update();
    });
  }

  String formatDuration(Duration d) {
    final twoDigits = (int n) => n.toString().padLeft(2, '0');
    return '${twoDigits(d.inMinutes)}:${twoDigits(d.inSeconds % 60)}';
  }
}
