import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/widgets/custom_button.dart';
import 'package:moo_logue/app/widgets/rounded_asset_image.dart';

class JumpBackInContainer extends StatelessWidget {
  const JumpBackInContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(25),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          width: MediaQuery.of(context).size.width * 0.8,
          decoration: BoxDecoration(
            color: AppColors.closeIconBgColor.withValues(alpha: 0.25),
            borderRadius: BorderRadius.circular(25),
          ),
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RoundedAssetImage(
                imagePath: 'assets/temp/temp_cow_image.png',
                width: double.infinity,
                height: 100.h,
                fit: BoxFit.cover,
                borderRadius: 20,
              ),
              20.heightBox,
              Text(
                'Moo Basics',
                style: context.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              6.heightBox,
              Text('Level 1', style: context.textTheme.titleSmall),
              6.heightBox,
              Text(
                '1.2 Happy Moos on a Farm',
                style: context.textTheme.titleLarge?.copyWith(fontSize: 14.sp),
              ),
              16.heightBox,
              ClipRRect(
                borderRadius: BorderRadius.circular(2),

                child: LinearProgressIndicator(
                  value: 0.5, // 0.0 to 1.0 (e.g., 0.5 means 50%)
                  backgroundColor: AppColors.sliderColor.withValues(alpha: 0.5),
                  valueColor: AlwaysStoppedAnimation<Color>(AppColors.primary),
                  minHeight: 4.h,
                ),
              ),
              20.heightBox,
              CustomButton(
                text: AppString.continueLbl,
                onTap: () {},
                height: 40.h,
                fontWeight: FontWeight.w600,
                textSize: 12.sp,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
