import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:moo_logue/app/modules/home/views/about_us_view.dart';
import 'package:moo_logue/app/modules/home/views/home_view.dart';
import 'package:moo_logue/app/modules/home/views/leader_board_view.dart';
import 'package:moo_logue/app/modules/home/views/learn_listening_view.dart';
import 'package:moo_logue/app/routes/app_routes.dart';
import 'package:moo_logue/app/routes/index.js.dart';

class BottomBarController extends GetxController {
  RxInt currentIndex = 0.obs;

  void onItemTapped(int index) {
    // Animate to new page
    final oldIndex = currentIndex.value;
    currentIndex.value = index;
    if (currentIndex.value != oldIndex) {
      if (index == 0) {
        ctx!.go(Routes.homeView);
      } else if (index == 1) {
        ctx!.go(Routes.learnListeningView);
      } else if (index == 2) {
        ctx!.go(Routes.learnBoardView);
      } else if (index == 3) {
        ctx!.go(Routes.aboutUsView);
      }
    }
  }

  @override
  void dispose() {
    super.dispose();
  }
}
