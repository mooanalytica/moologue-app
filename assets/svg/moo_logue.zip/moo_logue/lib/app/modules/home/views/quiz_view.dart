import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/modules/home/controllers/quiz_view_controller.dart';

class QuizView extends StatelessWidget {
  QuizView({super.key});

  QuizViewController quizViewController = Get.put(QuizViewController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.horizontalPadding),
        child: Column(
          children: [
            Row(children: [SvgPicture.asset(AppAssets.backArrow_icon)]),
          ],
        ),
      ),
    );
  }
}
