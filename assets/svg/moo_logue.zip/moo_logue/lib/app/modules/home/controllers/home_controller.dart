import 'package:get/get.dart';

class HomeController extends GetxController {
  final List<DayStreak> weeklyStreak = [
    DayStreak(day: "Mo", status: StreakStatus.past),
    DayStreak(day: "Tu", status: StreakStatus.past),
    DayStreak(day: "We", status: StreakStatus.past),
    DayStreak(day: "Th", status: StreakStatus.current),
    DayStreak(day: "Fr", status: StreakStatus.future),
    DayStreak(day: "Sa", status: StreakStatus.future),
    DayStreak(day: "Su", status: StreakStatus.future),
  ];
}

enum StreakStatus { past, current, future }

class DayStreak {
  final String day;
  final StreakStatus status;

  DayStreak({required this.day, required this.status});
}
