import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/modules/home/controllers/home_controller.dart';
import 'package:moo_logue/app/modules/home/widgets/discover_container.dart';
import 'package:moo_logue/app/modules/home/widgets/jump_back_in_container.dart';
import 'package:moo_logue/app/widgets/common_home_app_bar.dart';
import 'package:moo_logue/app/widgets/custom_button.dart';
import 'package:moo_logue/app/widgets/rounded_asset_image.dart';

class HomeView extends StatelessWidget {
  HomeView({Key? key}) : super(key: key);
  final controller = Get.put(HomeController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomHomeAppBar(),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            20.heightBox,

            /// Top Poster
            Container(
              height: 156.h,
              width: double.infinity,
              padding: EdgeInsets.only(left: 20.w),

              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        10.heightBox,
                        Text(
                          'New Sound Catalog',
                          style: context.textTheme.headlineMedium?.copyWith(
                            color: AppColors.whiteColor,
                            fontWeight: FontWeight.w600,
                            fontSize: 18.sp,
                          ),
                        ),
                        10.heightBox,
                        Expanded(
                          child: Text(
                            'Tap to explore the latest sounds and discover what’s new and exciting!',

                            style: context.textTheme.bodySmall?.copyWith(
                              color: AppColors.whiteColor,
                            ),
                          ),
                        ),
                        10.heightBox,
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 20.w,
                            vertical: 10.h,
                          ),
                          decoration: BoxDecoration(
                            color: context.theme.canvasColor,
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: Text(
                            'Explore',
                            style: context.textTheme.titleLarge?.copyWith(
                              color: context.isDarkMode
                                  ? AppColors.whiteColor
                                  : AppColors.primary,
                              fontSize: 12.sp,
                            ),
                          ),
                        ),
                        10.heightBox,
                      ],
                    ),
                  ),
                  20.widthBox,
                  RoundedAssetImage(
                    imagePath: AppAssets.homeBanner,
                    width: 150.w,
                    height: 156.h,
                    borderRadiusMain: BorderRadius.horizontal(
                      right: Radius.circular(10),
                      left: Radius.circular(25),
                    ),
                  ),
                ],
              ),
            ).paddingSymmetric(horizontal: AppSize.horizontalPadding),
            35.heightBox,

            /// Streak Container
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: BackdropFilter(
                filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: AppColors.closeIconBgColor.withValues(alpha: 0.25),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text(
                        'This Weeks Streak',
                        style: context.textTheme.headlineMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      16.heightBox,
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: List.generate(
                          controller.weeklyStreak.length,
                          (index) => buildStreakCircle(
                            controller.weeklyStreak[index],
                            context,
                          ),
                        ),
                      ),
                      16.heightBox,
                      CustomButton(
                        text: 'Start today’s lesson',
                        onTap: () {},
                        height: 40.h,
                        fontWeight: FontWeight.w600,
                        textSize: 12.sp,
                      ),
                    ],
                  ),
                ),
              ),
            ).paddingSymmetric(horizontal: AppSize.horizontalPadding),
            35.heightBox,

            ///Jump Back In
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'Jump Back In',
                  style: context.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 18.sp,
                  ),
                ).paddingSymmetric(horizontal: AppSize.horizontalPadding),
                16.heightBox,
                SizedBox(
                  height: 301.h,
                  child: ListView.builder(
                    itemCount: 10,
                    padding: EdgeInsets.only(left: AppSize.horizontalPadding),
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return JumpBackInContainer().paddingOnly(right: 20.w);
                    },
                  ),
                ),
              ],
            ),
            35.heightBox,

            /// Discover
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  'Discover',
                  style: context.textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                    fontSize: 18.sp,
                  ),
                ).paddingSymmetric(horizontal: AppSize.horizontalPadding),
                16.heightBox,
                SizedBox(
                  height: 300.h,
                  child: ListView.builder(
                    itemCount: 10,
                    shrinkWrap: true,
                    padding: EdgeInsets.only(left: AppSize.horizontalPadding),
                    scrollDirection: Axis.horizontal,
                    itemBuilder: (context, index) {
                      return DiscoverContainer().paddingOnly(right: 20.w);
                    },
                  ),
                ),
              ],
            ),
            35.heightBox,
          ],
        ),
      ),
    );
  }

  Widget buildStreakCircle(DayStreak streak, BuildContext context) {
    Color fillColor;
    Color borderColor;
    Color iconColor;

    switch (streak.status) {
      case StreakStatus.past:
        fillColor = const Color(0xFF367A23);
        borderColor = Colors.transparent;
        iconColor = Colors.white;
        break;
      case StreakStatus.current:
        fillColor = const Color(0xFFA4D23B).withValues(alpha: 0.10);
        borderColor = const Color(0xFFA4D23B);
        iconColor = const Color(0xFFE7F0DA);
        break;
      case StreakStatus.future:
        fillColor = Colors.transparent;
        borderColor = const Color(0xFFE7F0DA);
        iconColor = const Color(0xFFE7F0DA);
        break;
    }

    return Column(
      children: [
        Container(
          height: 35.h,
          width: 35.h,
          decoration: BoxDecoration(
            color: fillColor,
            border: Border.all(color: borderColor),
            shape: BoxShape.circle,
          ),
          padding: EdgeInsets.all(7),
          child: Center(
            child: SvgPicture.asset(
              AppAssets.wheatIcon,
              colorFilter: ColorFilter.mode(iconColor, BlendMode.srcIn),
            ),
          ),
        ),
        2.heightBox,
        Text(streak.day, style: context.textTheme.labelMedium),
      ],
    );
  }
}
