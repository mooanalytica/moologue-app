import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/widgets/custom_button.dart';
import 'package:moo_logue/app/widgets/rounded_asset_image.dart';

class DiscoverContainer extends StatelessWidget {
  const DiscoverContainer({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(25),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          width: 250.w,
          decoration: BoxDecoration(
            color: AppColors.closeIconBgColor.withValues(alpha: 0.25),
            borderRadius: BorderRadius.circular(25),
          ),
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RoundedAssetImage(
                imagePath: 'assets/temp/temp_cow_image.png',
                width: double.infinity,
                height: 100.h,
                fit: BoxFit.cover,
                borderRadius: 25,
              ),
              20.heightBox,
              Text(
                'Mother Knows Moo: How Cows Talk to Their Calves',
                maxLines: 2,
                style: context.textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              6.heightBox,
              Text(
                'A closer look at the gentle, powerful vocal bond between mother cows and their newborns.',
                maxLines: 3,
                style: context.textTheme.titleSmall?.copyWith(
                  overflow: TextOverflow.ellipsis,
                  fontWeight: FontWeight.w400,
                ),
              ),

              20.heightBox,
              Row(
                children: [
                  Text(
                    'Read more',
                    maxLines: 3,
                    style: context.textTheme.bodySmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                  10.widthBox,
                  SvgPicture.asset(AppAssets.rightLongArrow),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
