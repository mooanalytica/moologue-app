import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';

class LeaderBoardController extends GetxController {
  var selectedIndex = 0.obs;

  void updateIndex(int index) {
    selectedIndex.value = index;
  }

  RxList<Map<String, dynamic>> weekList = <Map<String, dynamic>>[
    {
      "Icon": AppAssets.weekoneIcon,
      "Image": AppAssets.weekOneImage,
      "Title": AppString.weekOneText,
      "SubTitle": AppString.weekOneDisc,
      "Points": AppString.weekOnePoints,
    },
    {
      "Icon": AppAssets.weektwoIcon,
      "Image": AppAssets.weekTwoImage,
      "Title": AppString.weekTwoText,
      "SubTitle": AppString.weekTwoDisc,
      "Points": AppString.weekTwoPoints,
    },
    {
      "Icon": AppAssets.weekthreeIcon,
      "Image": AppAssets.weekThreeImage,
      "Title": AppString.weekThreeText,
      "SubTitle": AppString.weekThreeDisc,
      "Points": AppString.weekThreePoints,
    },
    {
      "Digit": AppString.weekDigitFour,
      "Image": AppAssets.weekFourImage,
      "Title": AppString.weekFourText,
      "SubTitle": AppString.weekFourDisc,
      "Points": AppString.weekFourPoints,
    },
    {
      "Digit": AppString.weekDigitFive,
      "Image": AppAssets.weekFiveImage,
      "Title": AppString.weekFiveText,
      "SubTitle": AppString.weekFiveDisc,
      "Points": AppString.weekFivePoints,
    },
    {
      "Digit": AppString.weekDigitSix,
      "Image": AppAssets.weekSixImage,
      "Title": AppString.weekSixText,
      "SubTitle": AppString.weekSixDisc,
      "Points": AppString.weekSixPoints,
    },
    {
      "Digit": AppString.weekDigitSeven,
      "Image": AppAssets.weekSevenImage,
      "Title": AppString.weekSevenText,
      "SubTitle": AppString.weekSevenDisc,
      "Points": AppString.weekSevenPoints,
    },
    {
      "Digit": AppString.weekDigitEight,
      "Image": AppAssets.weekOneImage,
      "Title": AppString.weekEightText,
      "SubTitle": AppString.weekEightDisc,
      "Points": AppString.weekEightPoints,
    },
  ].obs;
}
