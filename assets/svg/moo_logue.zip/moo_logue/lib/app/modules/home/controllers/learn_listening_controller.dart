import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';

class LearnListeningController extends GetxController {
  RxList<Map<String, dynamic>> learnListening = <Map<String, dynamic>>[
    {
      'LearnName': AppString.emotionalCalls,
      'LearnDisc': AppString.emotionalCallsDisc,
    },
    {
      'LearnName': AppString.feelingsSounds,
      'LearnDisc': AppString.feelingsSoundsDisc,
    },
    {
      'LearnName': AppString.feelingsSounds,
      'LearnDisc': AppString.feelingsSoundsDisc,
    },
  ].obs;
  RxList<Map<String, dynamic>> learnListeningTwo = <Map<String, dynamic>>[
    {'LevelNumber': AppString.levelOne, 'LevelDisc': AppString.levelOneDisc},
    {'LevelNumber': AppString.levelTwo, 'LevelDisc': AppString.levelTwoDisc},
  ].obs;
}
