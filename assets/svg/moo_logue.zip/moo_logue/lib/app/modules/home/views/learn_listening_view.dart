import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/modules/home/controllers/learn_listening_controller.dart';
import 'package:moo_logue/app/modules/home/views/quiz_view.dart';
import 'package:moo_logue/app/routes/app_routes.dart';
import 'package:moo_logue/app/routes/index.js.dart';
import 'package:moo_logue/app/widgets/common_home_app_bar.dart';
import 'package:moo_logue/app/widgets/custom_button.dart';
import 'package:moo_logue/app/widgets/rounded_asset_image.dart';

class LearnListeningView extends StatelessWidget {
  LearnListeningView({super.key});
  final controller = Get.put(LearnListeningController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomHomeAppBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          25.heightBox,
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: AppSize.horizontalPadding,
            ),
            child: Text(
              AppString.learnByListening,
              style: context.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          16.heightBox,
          SizedBox(
            height: 225.h,
            child: ListView.builder(
              itemCount: controller.learnListening.length,
              shrinkWrap: true,
              padding: EdgeInsets.only(left: AppSize.horizontalPadding),
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(25),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                      child: GestureDetector(
                        onTap: () {
                          ctx?.push(Routes.emotionalCallsView);
                        },
                        child: Container(
                          width: 260.w,
                          decoration: BoxDecoration(
                            color: AppColors.closeIconBgColor.withValues(
                              alpha: 0.20,
                            ),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          padding: EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              RoundedAssetImage(
                                imagePath: AppAssets.emotionalCallsImage,
                                width: double.infinity,
                                height: 100.h,
                                fit: BoxFit.cover,
                                borderRadius: 25,
                              ),
                              20.heightBox,
                              Text(
                                "${controller.learnListening[index]['LearnName']}",
                                maxLines: 2,
                                style: context.textTheme.headlineMedium
                                    ?.copyWith(
                                      fontWeight: FontWeight.w600,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                              ),
                              8.heightBox,
                              Text(
                                "${controller.learnListening[index]['LearnDisc']}",
                                maxLines: 3,
                                style: context.textTheme.bodyMedium?.copyWith(
                                  overflow: TextOverflow.ellipsis,
                                  fontWeight: FontWeight.w400,
                                ),
                              ),
                              5.heightBox,
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          16.heightBox,
          Padding(
            padding: EdgeInsets.symmetric(
              horizontal: AppSize.horizontalPadding,
            ),
            child: Text(
              AppString.quizMe,
              style: context.textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          16.heightBox,
          SizedBox(
            height: 268.h,
            child: ListView.builder(
              itemCount: controller.learnListeningTwo.length,
              shrinkWrap: true,
              padding: EdgeInsets.only(left: AppSize.horizontalPadding),
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(right: 20),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(25),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                      child: Container(
                        height: 300.h,
                        width: MediaQuery.of(context).size.width * 0.8,
                        decoration: BoxDecoration(
                          color: AppColors.closeIconBgColor.withValues(
                            alpha: 0.25,
                          ),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        padding: EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            RoundedAssetImage(
                              imagePath: AppAssets.quizMeImage,
                              width: double.infinity,
                              height: 100.h,
                              fit: BoxFit.cover,
                              borderRadius: 20,
                            ),
                            16.heightBox,
                            Text(
                              AppString.mooBasics,
                              style: context.textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            6.heightBox,
                            Text(
                              "${controller.learnListeningTwo[index]['LevelNumber']}",
                              style: context.textTheme.titleSmall,
                            ),
                            6.heightBox,
                            Text(
                              "${controller.learnListeningTwo[index]['LevelDisc']}",
                              style: context.textTheme.titleLarge?.copyWith(
                                fontSize: 14.sp,
                              ),
                            ),
                            16.heightBox,
                            index == 1
                                ? Padding(
                                    padding: EdgeInsets.symmetric(
                                      horizontal: AppSize.horizontalPadding,
                                      vertical: 10,
                                    ),
                                    child: Row(
                                      children: [
                                        SvgPicture.asset(
                                          AppAssets.starIcon,
                                          height: 16.h,
                                          width: 16.w,
                                        ),
                                        10.widthBox,
                                        Text(
                                          AppString.levelPercentage,
                                          style: context.textTheme.titleLarge
                                              ?.copyWith(
                                                fontSize: 12.sp,
                                                color: AppColors.primary,
                                              ),
                                        ),
                                        Spacer(),
                                        Text(
                                          AppString.retackQuiz,
                                          style: context.textTheme.titleLarge
                                              ?.copyWith(
                                                fontSize: 12.sp,
                                                color: AppColors.primary,
                                              ),
                                        ),
                                        10.widthBox,
                                        SvgPicture.asset(
                                          AppAssets.rightLongArrowIcon,
                                          height: 10.h,
                                          width: 18.w,
                                        ),
                                      ],
                                    ),
                                  )
                                : CustomButton(
                                    text: AppString.startQuiz,
                                    onTap: () {
                                      Get.toNamed(Routes.quizView);
                                    },
                                    height: 42.h,
                                    fontWeight: FontWeight.w600,
                                    textSize: 12.sp,
                                  ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
