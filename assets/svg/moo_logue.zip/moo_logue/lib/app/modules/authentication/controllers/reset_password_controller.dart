import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class ResetPasswordController extends GetxController {
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();

  RxBool isButtonEnabled = false.obs;
  RxBool isPasswordVisible = false.obs;
  RxBool isPasswordVisible1 = false.obs;
  RxBool isShowPasswordOptionShow = false.obs;
  RxBool isShowPasswordOptionShow1 = false.obs;

  void checkForButtonEnabled() {
    bool oldValue = isButtonEnabled.value;
    if (newPasswordController.text.isNotEmpty &&
        confirmPasswordController.text.isNotEmpty) {
      isButtonEnabled.value = true;
    } else {
      isButtonEnabled.value = false;
    }

    if (oldValue != isButtonEnabled.value) {
      update();
    }
  }

  void checkForPasswordVisibility() {
    bool oldValue = isShowPasswordOptionShow.value;
    log(
      'passwordController.text==============>>>${newPasswordController.text}',
    );
    if (newPasswordController.text.isNotEmpty) {
      isShowPasswordOptionShow.value = true;
    } else {
      isShowPasswordOptionShow.value = false;
    }

    if (oldValue != isShowPasswordOptionShow.value) {
      update();
    }
  }

  void checkForPasswordVisibilityOne() {
    bool oldValue = isShowPasswordOptionShow1.value;
    log(
      'passwordController.text==============>>>${confirmPasswordController.text}',
    );
    if (confirmPasswordController.text.isNotEmpty) {
      isShowPasswordOptionShow1.value = true;
    } else {
      isShowPasswordOptionShow1.value = false;
    }

    if (oldValue != isShowPasswordOptionShow1.value) {
      update();
    }
  }
}
