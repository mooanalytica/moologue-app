import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/modules/authentication/controllers/display_view_controller.dart';
import 'package:moo_logue/app/routes/app_routes.dart';
import 'package:moo_logue/app/widgets/common_home_app_bar.dart';
import 'package:moo_logue/app/widgets/custom_appbar.dart';

class DisplayView extends StatelessWidget {
  DisplayView({super.key});
  final controller = Get.put(DisplayViewController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(text: AppString.display),
      body: Padding(
        padding: EdgeInsetsGeometry.symmetric(
          horizontal: AppSize.horizontalPadding,
        ),
        child: Column(
          children: List.generate(
            controller.displayList.length,
            (index) => Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ListTile(
                  leading: SvgPicture.asset(
                    "${controller.displayList[index]['DisplayIcon']}",
                    height: 20.h,
                    width: 22.w,
                    colorFilter: ColorFilter.mode(
                      context.isDarkMode
                          ? AppColors.whiteColor
                          : AppColors.primaryTextColor,
                      BlendMode.srcIn,
                    ),
                  ),
                  title: Text(
                    "${controller.displayList[index]['DisplayName']}",
                    style: context.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  trailing: Text(
                    AppString.edit,
                    style: context.textTheme.titleSmall?.copyWith(
                      decoration: TextDecoration.underline,
                      decorationThickness: 2,
                    ),
                  ),
                ),
                16.heightBox,
                Padding(
                  padding: EdgeInsets.symmetric(
                    horizontal: AppSize.horizontalPadding,
                  ),
                  child: Text(
                    "${controller.displayList[index]['DisplayDisc']}",
                    style: context.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
                10.heightBox,
                Divider(
                  color: context.isDarkMode
                      ? AppColors.whiteColor
                      : AppColors.primaryTextColor.withValues(alpha: 0.1),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
