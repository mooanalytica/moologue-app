import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class ForgotPasswordController extends GetxController {
  TextEditingController forgotEmailCnt = TextEditingController();
  RxBool isButtonEnabled = false.obs;

  void checkForButtonEnabled() {
    bool oldValue = isButtonEnabled.value;
    if (forgotEmailCnt.text.isNotEmpty) {
      isButtonEnabled.value = true;
    } else {
      isButtonEnabled.value = false;
    }

    if (oldValue != isButtonEnabled.value) {
      update();
    }
  }
}
