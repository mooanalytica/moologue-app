import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:go_router/go_router.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:moo_logue/app/core/constants/app_sizes.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';
import 'package:moo_logue/app/core/extention/sized_box_extention.dart';
import 'package:moo_logue/app/modules/authentication/controllers/settings_view_controller.dart';
import 'package:moo_logue/app/routes/app_routes.dart';
import 'package:moo_logue/app/routes/index.js.dart';
import 'package:moo_logue/app/widgets/custom_appbar.dart';

class SettingsView extends StatelessWidget {

  final controller = Get.put(SettingsViewController());
  SettingsView({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppbar(text: AppString.settings),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: AppSize.horizontalPadding),
        child: Theme(
          data: ThemeData(
            splashFactory: NoSplash.splashFactory,
            splashColor: Colors.transparent,
            highlightColor: Colors.transparent,
          ),
          child: Column(
            children: List.generate(
              controller.settingsList.length,
              (index) => Column(
                children: [
                  ListTile(
                    leading: SvgPicture.asset(
                      "${controller.settingsList[index]['SettingsIcon']}",
                      height: 20.h,
                      width: 20.w,
                      colorFilter: ColorFilter.mode(
                        context.isDarkMode
                            ? AppColors.whiteColor
                            : AppColors.primaryTextColor,
                        BlendMode.srcIn,
                      ),
                    ),
                    title: Text(
                      "${controller.settingsList[index]['SettingsName']}",
                      style: context.textTheme.headlineMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    trailing: index == 3
                        ? null
                        : SvgPicture.asset(
                            AppAssets.arrowRight_icon,
                            height: 16.h,
                            width: 10.w,
                            colorFilter: ColorFilter.mode(
                              context.isDarkMode
                                  ? AppColors.whiteColor
                                  : AppColors.primaryTextColor,
                              BlendMode.srcIn,
                            ),
                          ),

                    onTap: () {
                      index == 1 ? ctx!.push(Routes.displayView) : null;
                    },
                  ),
                  Divider(
                    color: context.isDarkMode
                        ? AppColors.whiteColor
                        : AppColors.primaryTextColor.withValues(alpha: 0.1),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
