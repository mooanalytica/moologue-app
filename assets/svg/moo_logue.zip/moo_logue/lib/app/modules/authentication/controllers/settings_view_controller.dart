import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';

class SettingsViewController extends GetxController {
  RxList<Map<String, dynamic>> settingsList = <Map<String, dynamic>>[
    {
      'SettingsIcon': AppAssets.accountInfo_icon,
      'SettingsName': AppString.accountInfo,
    },
    {'SettingsIcon': AppAssets.display_icon, 'SettingsName': AppString.display},
    {
      'SettingsIcon': AppAssets.helpCenter_icon,
      'SettingsName': AppString.helpCenter,
    },
    {'SettingsIcon': AppAssets.logout_icon, 'SettingsName': AppString.logout},
  ].obs;
}
