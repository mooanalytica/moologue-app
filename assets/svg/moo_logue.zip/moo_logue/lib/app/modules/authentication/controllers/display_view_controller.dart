import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_assets.dart';
import 'package:moo_logue/app/core/constants/app_strings.dart';

class DisplayViewController extends GetxController {
  RxList<Map<String, dynamic>> displayList = <Map<String, dynamic>>[
    {
      'DisplayIcon': AppAssets.fontSizeIcon,
      'DisplayName': AppString.fontSize,
      'DisplayDisc': AppString.large,
    },
    {
      'DisplayIcon': AppAssets.colorBlindModeIcon,
      'DisplayName': AppString.colorBlindMode,
      'DisplayDisc': AppString.enabled,
    },
  ].obs;
}
