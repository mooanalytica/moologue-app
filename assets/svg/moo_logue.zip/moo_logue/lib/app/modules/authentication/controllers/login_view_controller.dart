import 'dart:developer';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

class LoginViewController extends GetxController {
  TextEditingController loginEmailCnt = TextEditingController();
  TextEditingController loginPasswordCnt = TextEditingController();

  RxBool isButtonEnabled = false.obs;
  RxBool isPasswordVisible = false.obs;
  RxBool isShowPasswordOptionShow = false.obs;

  void checkForButtonEnabled() {
    bool oldValue = isButtonEnabled.value;
    if (loginEmailCnt.text.isNotEmpty && loginPasswordCnt.text.isNotEmpty) {
      isButtonEnabled.value = true;
    } else {
      isButtonEnabled.value = false;
    }

    if (oldValue != isButtonEnabled.value) {
      update();
    }
  }

  void checkForPasswordVisibility() {
    bool oldValue = isShowPasswordOptionShow.value;
    log('passwordController.text==============>>>${loginPasswordCnt.text}');
    if (loginPasswordCnt.text.isNotEmpty) {
      isShowPasswordOptionShow.value = true;
    } else {
      isShowPasswordOptionShow.value = false;
    }

    if (oldValue != isShowPasswordOptionShow.value) {
      update();
    }
  }
}
