import 'package:flutter/cupertino.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:moo_logue/app/core/constants/app_colors.dart';
import 'package:pinput/pinput.dart';

class ResetVerificationController extends GetxController {
  RxBool isButtonEnabled = false.obs;
  TextEditingController pinController = TextEditingController();

  void checkForButtonEnabled(String value) {
    bool oldValue = isButtonEnabled.value;
    if (value.length >= 6) {
      isButtonEnabled.value = true;
    } else {
      isButtonEnabled.value = false;
    }

    if (oldValue != isButtonEnabled.value) {
      update();
    }
  }

  final defaultPinTheme = PinTheme(
    width: 61.w,
    height: 75.h,
    textStyle: const TextStyle(fontSize: 20, color: AppColors.primaryTextColor),
    decoration: BoxDecoration(
      color: AppColors.closeIconBgColor.withValues(alpha: 0.25),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: AppColors.pinputBorder),
    ),
  );
}
