import 'package:get/get.dart';

class OnBordingController extends GetxController {}
