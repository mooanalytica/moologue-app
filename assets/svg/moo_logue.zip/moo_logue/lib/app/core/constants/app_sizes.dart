import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppSize {
  static double horizontalPadding = 20.w;
}
