enum FontSizeOption { small, medium, large }
