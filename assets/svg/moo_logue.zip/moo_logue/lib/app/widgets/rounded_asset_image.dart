import 'package:flutter/material.dart';

class RoundedAssetImage extends StatelessWidget {
  final String imagePath;
  final double width;
  final double height;
  final double borderRadius;
  final BoxFit fit;
  final BorderRadiusGeometry? borderRadiusMain;

  const RoundedAssetImage({
    super.key,
    required this.imagePath,
    this.width = 100,
    this.height = 100,
    this.borderRadius = 8,
    this.fit = BoxFit.cover,
    this.borderRadiusMain,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: borderRadiusMain ?? BorderRadius.circular(borderRadius),
      child: Image.asset(imagePath, width: width, height: height, fit: fit),
    );
  }
}
