import 'dart:developer';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:moo_logue/app/bindings/initial_binding.dart';
import 'package:moo_logue/app/core/enums/font_size_option.dart';
import 'package:moo_logue/app/modules/home/views/fence_Interaction_call_view.dart';
import 'package:moo_logue/app/modules/home/controllers/bottom_bar_controller.dart';
import 'package:moo_logue/app/routes/app_pages.dart';

import 'app/controllers/theme_controller.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);
  await ScreenUtil.ensureScreenSize();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final themeController = Get.put(ThemeController());
  final controller = Get.put(BottomBarController());
  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(430, 932),
      minTextAdapt: true,
      builder: (_, child) => Obx(
        () => MaterialApp.router(
          debugShowCheckedModeBanner: false,
          theme: themeController.lightTheme,
          darkTheme: themeController.darkTheme,
          themeMode: themeController.themeMode.value,
          routerConfig: AppPages.routes,
          // getPages: AppPages.routes,
          // initialRoute: AppPages.initial,
          //
          // initialBinding: InitialBinding(),
          builder: (context, child) {
            return MediaQuery(
              data: MediaQuery.of(context).copyWith(
                textScaler: TextScaler.linear(
                  themeController.fontSizeOption.value == FontSizeOption.small
                      ? 0.9
                      : themeController.fontSizeOption.value ==
                            FontSizeOption.large
                      ? 1.1
                      : 1,
                ),
              ),
              child: child!,
            );
          },
        ),
      ),
    );
  }
}
