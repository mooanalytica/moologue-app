package com.example.moo_logue

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
